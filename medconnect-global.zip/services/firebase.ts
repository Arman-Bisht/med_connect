// Import the functions you need from the SDKs you need
import { initializeApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

// Your web app's Firebase configuration that you provided
const firebaseConfig = {
  apiKey: "AIzaSyCEKk5kQCPXTmqg3SSHuUAq1UXq-d1Ahbk",
  authDomain: "medconnect-global-1.firebaseapp.com",
  projectId: "medconnect-global-1",
  storageBucket: "medconnect-global-1.firebasestorage.app",
  messagingSenderId: "692010641327",
  appId: "1:692010641327:web:caf40c23aa42db8f79715a",
  measurementId: "G-9WCMR2EH9S"
};


// Initialize Firebase
const app: FirebaseApp = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth: Auth = getAuth(app);
const db: Firestore = getFirestore(app);

// Export them for use in other parts of the app
export { app, auth, db };
